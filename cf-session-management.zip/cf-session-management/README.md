cf-session-management
=====================

This is the lab for the first Java Applications section that demonstrates the use of persistent HTTP Sessions.

  1. You will deploy an existing application, store data in an HTTP Session and see that it is lost if the application dies.
  1. Then you aill allocate a dedicated Redis service for persisting session information
  1.Then you will repeat step 1 and see how data is retained.

This application relies on built-in functionality of the Java Buildpack and requires no Java coding.

Application uses Spring Boot for configuration and setup.
