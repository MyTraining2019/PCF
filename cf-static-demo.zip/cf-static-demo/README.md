CF Static Demo
==============

Desmonstrates the use of a Buildpack for deploying a static web-site.

Requires use of the `static-file` buildpack:

    https://github.com/cloudfoundry-community/staticfile-buildpack.git 
